#!/usr/bin/env bash

# this function is ok
function miner_ver() {

  echo $CUSTOM_VERSION
}

# this function is ok
function miner_config_echo() {
        if [[ -z $CUSTOM_MINER ]]; then
                echo -e "${RED}\$CUSTOM_MINER is not defined${NOCOLOR}"
                return 1
        fi

        if [[ -e $CUSTOM_DIR/h-manifest.conf ]]; then
                source $CUSTOM_DIR/h-manifest.conf
        fi

        if [[ ! -z $CUSTOM_CONFIG_FILENAME ]]; then
                miner_echo_config_file $CUSTOM_CONFIG_FILENAME
        else
                echo -e "${RED}\$CUSTOM_CONFIG_FILENAME is not defined${NOCOLOR}";
                return 1
        fi

}

CUSTOM_DIR=$(dirname "$BASH_SOURCE")

. $CUSTOM_DIR/h-manifest.conf

[[ -z $CUSTOM_TEMPLATE ]] && echo -e "${YELLOW}CUSTOM_TEMPLATE is empty${NOCOLOR}" && return 1
[[ -z $CUSTOM_URL ]] && echo -e "${YELLOW}CUSTOM_URL is empty${NOCOLOR}" && return 2

echo "-a $CUSTOM_URL -p $CUSTOM_TEMPLATE" > $CUSTOM_CONFIG_FILENAME

MINER_NAME=miners/custom
